- Built a MERN application with user authentication that allows users to post interesting events that happened
in their lives, users can modify their own posts and like posts of other users
- Implemented all the CRUD operation using MongoDB, React and managed states of Application by using
Redux and implemented Authentication using Google login and JWT Token
- Tech Stack: React, Redux, Node.js, Express.js, MongoDB
